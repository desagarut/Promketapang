kpu
===

Aplikasi Sederhana Untuk Menampilkan Data Pemilih Tetap Pemilu Daerah