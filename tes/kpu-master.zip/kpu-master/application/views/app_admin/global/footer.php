      <footer class="well">
        <p><?php echo $this->config->item("lisensi_app"); ?></p>
      </footer>

    </div> <!-- /container -->

  </body>
</html>
